define('logging/config/environment', function() {
  return {
    default: {"modulePrefix":"logging"}
  };
});
