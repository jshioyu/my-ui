define('istio/config/environment', function() {
  return {
    default: {"modulePrefix":"istio"}
  };
});
