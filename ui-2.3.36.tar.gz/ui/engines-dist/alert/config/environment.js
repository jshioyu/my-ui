define('alert/config/environment', function() {
  return {
    default: {"modulePrefix":"alert"}
  };
});
