define('login/config/environment', function() {
  return {
    default: {"modulePrefix":"login"}
  };
});
