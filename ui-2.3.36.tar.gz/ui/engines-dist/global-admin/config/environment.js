define('global-admin/config/environment', function() {
  return {
    default: {"modulePrefix":"global-admin","APP":{}}
  };
});
