define('monitoring/config/environment', function() {
  return {
    default: {"modulePrefix":"monitoring"}
  };
});
