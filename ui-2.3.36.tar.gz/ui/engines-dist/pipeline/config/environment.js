define('pipeline/config/environment', function() {
  return {
    default: {"modulePrefix":"pipeline"}
  };
});
