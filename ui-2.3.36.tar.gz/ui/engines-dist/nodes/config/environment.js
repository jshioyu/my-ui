define('nodes/config/environment', function() {
  return {
    default: {"modulePrefix":"nodes"}
  };
});
