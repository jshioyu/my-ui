/* eslint-disable */
define('ui/config/node-asset-manifest', function() {
  return {
    default: {"bundles":{"alert":{"assets":[{"uri":"/engines-dist/alert/assets/engine-vendor.js?2.3-dev","type":"js"},{"uri":"/engines-dist/alert/assets/engine.js?2.3-dev","type":"js"}]},"global-admin":{"assets":[]},"istio":{"assets":[{"uri":"/engines-dist/istio/assets/engine-vendor.js?2.3-dev","type":"js"},{"uri":"/engines-dist/istio/assets/engine.js?2.3-dev","type":"js"}]},"logging":{"assets":[{"uri":"/engines-dist/logging/assets/engine-vendor.js?2.3-dev","type":"js"},{"uri":"/engines-dist/logging/assets/engine.js?2.3-dev","type":"js"}]},"login":{"assets":[{"uri":"/engines-dist/login/assets/engine-vendor.js?2.3-dev","type":"js"},{"uri":"/engines-dist/login/assets/engine.js?2.3-dev","type":"js"}]},"monitoring":{"assets":[{"uri":"/engines-dist/monitoring/assets/engine-vendor.js?2.3-dev","type":"js"},{"uri":"/engines-dist/monitoring/assets/engine.js?2.3-dev","type":"js"}]},"nodes":{"assets":[]},"pipeline":{"assets":[{"uri":"/engines-dist/pipeline/assets/engine-vendor.js?2.3-dev","type":"js"},{"uri":"/engines-dist/pipeline/assets/engine.js?2.3-dev","type":"js"}]}}}
  };
});
